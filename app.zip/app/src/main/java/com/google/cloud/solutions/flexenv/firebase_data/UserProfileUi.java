package com.google.cloud.solutions.flexenv.firebase_data;

import com.google.cloud.solutions.flexenv.user_account.account_property.objects.UserAccount;

/**
 * Created by mohamednagy on 12/24/2016.
 */
public interface UserProfileUi {
    void setUserIdentifierData(UserAccount userAccount);
}
