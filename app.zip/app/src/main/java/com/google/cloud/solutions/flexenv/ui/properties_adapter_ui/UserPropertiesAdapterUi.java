package com.google.cloud.solutions.flexenv.ui.properties_adapter_ui;

import android.view.View;
import android.view.ViewGroup;

/**
 * Created by mohamednagy on 12/25/2016.
 */
public interface UserPropertiesAdapterUi {

    View getView(int position, ViewGroup parent);
    int getCount();
}
